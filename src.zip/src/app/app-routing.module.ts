import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListClasseComponent } from './classe/list-classe/list-classe.component';
import { AddClasseComponent } from './classe/add-classe/add-classe.component';
import { AddEtudiantComponent } from './etudiant/add-etudiant/add-etudiant.component';
import { ListEtudiantComponent } from './etudiant/list-etudiant/list-etudiant.component';
import { ListInscriptionComponent } from './inscription/list-inscription/list-inscription.component';
import { AddInscriptionComponent } from './inscription/add-inscription/add-inscription.component';

const routes: Routes = [
  {
    path: '',  
    
      },
  { path: 'etudiant', loadChildren: () => import('./etudiant/etudiant.module').then(m => m.EtudiantModule) },
  { path: 'classe', loadChildren: () => import('./classe/classe.module').then(m => m.ClasseModule) },
 
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
