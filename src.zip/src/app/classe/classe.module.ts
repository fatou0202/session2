import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClasseRoutingModule } from './classe-routing.module';
import { ClasseComponent } from './classe.component';
import { AddEtudiantComponent } from '../etudiant/add-etudiant/add-etudiant.component';
import { AddClasseComponent } from './add-classe/add-classe.component';
import { ListClasseComponent } from './list-classe/list-classe.component';


@NgModule({
  declarations: [
    ClasseComponent,
    AddEtudiantComponent,
    AddClasseComponent,
    ListClasseComponent
  ],
  imports: [
    CommonModule,
    ClasseRoutingModule
  ]
})
export class ClasseModule { }
