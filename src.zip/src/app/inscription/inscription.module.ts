import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InscriptionRoutingModule } from './inscription-routing.module';
import { InscriptionComponent } from './inscription.component';
import { AddInscriptionComponent } from './add-inscription/add-inscription.component';
//import { ListInscriptionComponent } from './list-inscription/list-inscription.component';


@NgModule({
  declarations: [
    InscriptionComponent,
    AddInscriptionComponent,
   
  ],
  imports: [
    CommonModule,
    InscriptionRoutingModule
  ]
})
export class InscriptionModule { }
